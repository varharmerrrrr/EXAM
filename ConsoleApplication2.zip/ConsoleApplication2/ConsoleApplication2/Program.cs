﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {

        private static int q = 0;
        static void Main(string[] args)
        {
            do
            {
                try
                {
                    Console.WriteLine("Введите три числа типа Double x, y, z :");
                    double x = Convert.ToDouble(Console.ReadLine());
                    double y = Convert.ToDouble(Console.ReadLine());
                    double z = Convert.ToDouble(Console.ReadLine());
                    double w = Math.Pow(Math.Abs(Math.Cos(x) - Math.Cos(y)), 1 + 2 * Math.Pow(Math.Sin(y), 2)) * (1 + z + (z * z) / 2) + Math.Pow(z, 3) / 3 + Math.Pow(z, 4) / 4;
                    Console.WriteLine(" x = {0},\n y = {1},\n z = {2},\n w = {3}", x, y, z, w);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Введите нужный тип переменнной");
                    q++;
                }
            } while (q < 5);
            if (q == 5)
            {
                Console.WriteLine("Ввод неверных данных");
            }
        }
    }
}
